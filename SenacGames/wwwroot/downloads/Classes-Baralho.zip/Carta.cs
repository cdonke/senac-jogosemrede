﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Duvido
{
    public class Carta : IEquatable<Carta>
    {
        public Carta(Naipes naipe, ValoresCartas valor)
        {
            // Suit and Rank validation logic here

            Naipe = naipe;
            Valor = valor;
        }

        // Replace this with the plain get call like Fernando's answer in C# 6
        // You can also leave it and be careful or create a private readonly backing property
        public Naipes Naipe { get; private set; }

        public ValoresCartas Valor { get; private set; }

        public static bool operator ==(Carta left, Carta right)
        {
            // Review https://msdn.microsoft.com/en-US/library/ms173147%28v=vs.80%29.aspx
            // If both are null, or both are same instance, return true.
            if (ReferenceEquals(left, right))
            {
                return true;
            }

            // If one is null, but not both, return false.
            if (((object)left == null) || ((object)right == null))
            {
                return false;
            }

            // Return true if the fields match:
            return left.Equals(right);
        }

        public static bool operator !=(Carta left, Carta right)
        {
            return !(left == right);
        }

        public bool Equals(Carta other)
        {
            if (other == null)
            {
                return false;
            }

            return Valor == other.Valor && Naipe == other.Naipe;
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as Carta);
        }

        public override int GetHashCode()
        {
            return Naipe.GetHashCode() ^ Valor.GetHashCode();
        }

        // Not strictly needed but why not do it....
        public override string ToString()
        {
            // Take advantage of how the Enum.ToString() method functions
            return Valor.ToString() + " de " + Naipe.ToString();
        }
    }
}
