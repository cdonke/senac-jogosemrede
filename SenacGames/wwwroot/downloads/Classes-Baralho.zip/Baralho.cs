﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Duvido
{
    class Baralho
    {
        public Baralho()
        {
            cartas = new List<Carta>();
            foreach (Naipes naipe in Enum.GetValues(typeof(Naipes)))
            {
                foreach (ValoresCartas valor in Enum.GetValues(typeof(ValoresCartas)))
                {
                    cartas.Add(new Carta(naipe, valor));
                }
            }
        }

        public List<Carta> cartas { get; private set; }


        public void Embaralhar()
        {
            RNGCryptoServiceProvider provider = new RNGCryptoServiceProvider();
            int n = cartas.Count;
            while (n > 1)
            {
                byte[] box = new byte[1];
                do provider.GetBytes(box);
                while (!(box[0] < n * (Byte.MaxValue / n)));
                int k = (box[0] % n);
                n--;
                Carta value = cartas[k];
                cartas[k] = cartas[n];
                cartas[n] = value;
            }
        }
    }
}
