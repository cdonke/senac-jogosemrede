﻿using UnityEngine;
using System.Collections;
using WebSocket4Net;
using System;
using SuperSocket.ClientEngine;
using Newtonsoft.Json;

public class WebSocketManager : MonoBehaviour {

	public string WSServer = "";
	public GameObject prefab;

	WebSocket ws;
	string sessionId = "";

	// Use this for initialization
	void Start () {
		Debug.Log ("Starting");
		ws = new WebSocket (WSServer);
		AttachAndConnect ();
	}
	void AttachAndConnect()
	{
		sessionId = Guid.NewGuid ().ToString ();
		ws.Opened += new EventHandler (ws_Opened);
		ws.MessageReceived += new EventHandler<MessageReceivedEventArgs>(ws_FirstMessageReceived);
		ws.Closed += new EventHandler (ws_Closed);
		ws.Error += new EventHandler<ErrorEventArgs>(ws_Error);
		ws.Open ();
	}
	void ws_Opened(object sender, EventArgs e)
	{
		Debug.Log ("Opened");
	}
	void ws_Error(object sender, ErrorEventArgs e)
	{
		Debug.Log ("Error >> " + e.Exception.Message);
	}
	void ws_Closed(object sender, EventArgs e)
	{
		Debug.Log ("Closed");
	}
	void ws_MessageReceived(object sender, MessageReceivedEventArgs e)
	{
		Debug.Log ("Received >>  " + e.Message);
	}
	void ws_FirstMessageReceived(object sender, MessageReceivedEventArgs e)
	{
		var msg = DeserializeObject (e.Message);
		Debug.Log ("Session ID: " + msg.sender);
		sessionId = msg.sender;
		ws.MessageReceived -= ws_FirstMessageReceived;
		ws.MessageReceived += new EventHandler<MessageReceivedEventArgs>(ws_MessageReceived);	
		Instantiate (prefab);
	}


	public void Send(string action, string message)
	{
		Model obj = new Model () {
			sender = sessionId,
			action = action,
			message = message
		};
		string json = SerializeObject (obj);

		Debug.Log (json);
		if (ws.State == WebSocket4Net.WebSocketState.Open)
			ws.Send (json);
		else
			Debug.Log ("Not connected.. Ignoring.");
	}
	public void Send(int x, int y){
		Position p = new Position () {
			x = x,
			y = y
		};
		string json = SerializeObject (p);
		Send ("POSITION", json);
	}


	private string SerializeObject<T>(T requestData) 
	{
		object o = requestData as object;

		var obj = JsonConvert.SerializeObject(o, Formatting.None, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore
			});
		return obj;
	}
	private Model DeserializeObject(string responsetData) 
	{
		var obj = JsonConvert.DeserializeObject<Model>(responsetData);
		return obj;
	}



	class Model  {
		public string sender {
			get;
			set;
		}

		public string action {
			get;
			set;
		}
		public string message {
			get;
			set;
		}
	}

	class Position {
		public int x {
			get;
			set;
		}
		public int y {
			get;
			set;
		}
	}
}
