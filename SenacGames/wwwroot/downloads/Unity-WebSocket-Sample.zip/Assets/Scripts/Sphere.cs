﻿using UnityEngine;
using System.Collections;

public class Sphere : MonoBehaviour {

	public Camera cam;
	public float speed = 10f;

	Rigidbody me;
	WebSocketManager _socket;
	float maxWidth = 800;
	float maxHeight = 600;

	void Start()
	{
		if (cam == null)
			cam = Camera.main;
		
		_socket = (WebSocketManager)GameObject.Find("WebSocketObject")
			.GetComponent(typeof(WebSocketManager));

		me = GetComponent<Rigidbody> ();	

	}



	void FixedUpdate(){		
		InputMovement ();

		float targetWidth = Mathf.Clamp(me.position.x, 0, maxWidth);
		float targetHeight = Mathf.Clamp(me.position.y, 0, maxHeight);
		var newPosition = new Vector3(targetWidth, targetHeight, 0f);

		var worldCoordinates = cam.WorldToScreenPoint(newPosition);
		_socket.Send ((int)worldCoordinates.x, (int)worldCoordinates.y);
	}


	private void InputMovement()
	{
		if (Input.GetKey(KeyCode.W))
			me.MovePosition(me.position + Vector3.up * speed * Time.deltaTime);

		if (Input.GetKey(KeyCode.S))
			me.MovePosition(me.position - Vector3.up * speed * Time.deltaTime);

		if (Input.GetKey(KeyCode.D))
			me.MovePosition(me.position + Vector3.right * speed * Time.deltaTime);

		if (Input.GetKey(KeyCode.A))
			me.MovePosition(me.position - Vector3.right * speed * Time.deltaTime);
	}
}
