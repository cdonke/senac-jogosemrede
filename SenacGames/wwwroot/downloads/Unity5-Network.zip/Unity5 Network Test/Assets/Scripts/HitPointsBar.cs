﻿using UnityEngine;
using System.Collections;

public class HitPointsBar : MonoBehaviour {

	GUIStyle healthStyle;
	GUIStyle backStyle;
	DestroyableObject target;
	
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	}

	void Awake () {
		target = GetComponent<DestroyableObject>();
	}
	
	void OnGUI() {
		InitStyles();
		
		Vector3 pos = Camera.main.WorldToScreenPoint(transform.position);
		int fullWidth = 50;
		int width = (int) (((float) target.hitPoints / (float) DestroyableObject.MAX_HIT_POINTS) * (float) fullWidth);
		int height = 6;

		// Desenha fundo escuro para barra cheia
		GUI.color = Color.grey;
		GUI.backgroundColor = Color.grey;
		GUI.Box(new Rect(pos.x - fullWidth / 2 - 1, Screen.height - pos.y + 20, fullWidth + 2, height + 2), ".", backStyle);
		
		// Desenha barra com largura correspondente aos hitPoints monitorados
		GUI.color = Color.green;
		GUI.backgroundColor = Color.green;
		GUI.Box(new Rect(pos.x - fullWidth / 2, Screen.height - pos.y + 21, width, height), ".", healthStyle);
	}
	
	private void InitStyles () {
		if (healthStyle == null) {
			healthStyle = new GUIStyle(GUI.skin.box);
			healthStyle.normal.background = MakeTex(2, 2, new Color(0f, 1f, 0f, 1.0f));
		}
		
		if (backStyle == null) {
			backStyle = new GUIStyle(GUI.skin.box);
			backStyle.normal.background = MakeTex(2, 2, new Color(0f, 0f, 0f, 1.0f));
		}
	}
	
	private Texture2D MakeTex(int width, int height, Color col) {
		Color[] pix = new Color[width * height];
		for (int i = 0; i < pix.Length; i++) {
			pix[i] = col;
		}
		Texture2D result = new Texture2D(width, height);
		result.SetPixels(pix);
		result.Apply();
		return result;
	}
}
