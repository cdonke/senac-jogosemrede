﻿using UnityEngine;
using System.Collections;

public class SmartCamera : MonoBehaviour {

	private static SmartCamera mainCamera = null;

	private GameObject target;
	private Vector3 startPos;
	private Vector3 startDir;

	// Use this for initialization
	void Start () {
		if (SmartCamera.mainCamera == null)
			SmartCamera.mainCamera = this;

		this.target = null;
		this.startPos = this.transform.position;
		this.startDir = this.transform.forward;
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 nextPos, nextDir;

		if (this.target != null) {
			Transform t = this.target.transform;
			Vector3 idealPos = t.position - t.forward * 3.0f + t.up * 1.5f;
			nextPos = this.transform.position * 0.85f + idealPos * 0.15f;
			nextDir = t.position - nextPos;
		}
		else {
			nextPos = this.transform.position * 0.98f + this.startPos * 0.02f;
			nextDir = this.transform.forward * 0.98f + this.startDir * 0.02f;
		}
		
		this.transform.position = nextPos;
		this.transform.forward = nextDir;
	}

	public static SmartCamera GetInstance () {
		return SmartCamera.mainCamera;
	}

	public void SetTarget (GameObject target) {
		this.target = target;
	}
}
