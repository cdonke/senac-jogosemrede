﻿using UnityEngine;
// using UnityEngine.Networking;
using System.Collections;

public class Bullet : MonoBehaviour {

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	}

	void OnCollisionEnter (Collision collision) {
		DestroyableObject hitObject = collision.gameObject.GetComponent<DestroyableObject>();
		if (hitObject != null) {
			hitObject.TakeDamage(10);
			Destroy(this.gameObject);
		}
	}
}
