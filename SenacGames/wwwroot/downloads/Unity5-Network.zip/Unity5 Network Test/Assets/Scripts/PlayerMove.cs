﻿using UnityEngine;
using UnityEngine.Networking;
using System.Collections;

public class PlayerMove : NetworkBehaviour {

	public GameObject bulletPrefab;

	private const float MOVE_RATE = 4.0f;
	private const float ROTATE_RATE = 100.0f;
	private const float BULLET_SPEED = 8.0f;
	private const float BULLET_LIFETIME = 2.0f;

	public override void OnStartLocalPlayer () {
		GetComponentInChildren<MeshRenderer>().material.color = Color.red;
		SmartCamera.GetInstance().SetTarget(this.gameObject);
	}

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
		if (this.isLocalPlayer) {
			float deltaTime = Time.smoothDeltaTime;
			float horz = Input.GetAxis("Horizontal");
			float vert = Input.GetAxis("Vertical");

			this.transform.Rotate(0.0f, horz * ROTATE_RATE * deltaTime, 0.0f);
			this.transform.position = this.transform.position + this.transform.forward * vert * MOVE_RATE * deltaTime;

			if (Input.GetButtonDown("Fire1")) {
				// Esta chamada eh feita pelos clientes, mas executada no servidor
				CmdFireBullet();
			}
		}
	}

	[Command]
	void CmdFireBullet ()	{
		// Metodo [Command] eh executado somente no servidor
		// print("CmdFireBullet() running, check if this is the server");

		Vector3 startPos = this.transform.position + this.transform.forward * 0.8f;
		GameObject bullet = (GameObject) Instantiate(this.bulletPrefab, startPos, this.transform.rotation);

		// Velocidade do Rigidbody serah sincronizada nos clientes
		bullet.GetComponent<Rigidbody>().velocity = transform.forward * BULLET_SPEED;

		// Faz bullet ser instanciada nos clientes
		NetworkServer.Spawn(bullet);

		// Quando bullet for destruida no servidor, sera destruida tambem nos clientes
		Destroy(bullet, BULLET_LIFETIME);        
	}
}
