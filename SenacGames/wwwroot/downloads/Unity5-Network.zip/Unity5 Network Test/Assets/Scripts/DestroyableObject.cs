﻿using UnityEngine;
using UnityEngine.Networking;
using System.Collections;

public class DestroyableObject : NetworkBehaviour {

	public const int MAX_HIT_POINTS = 100;

	[SyncVar]
	public int hitPoints = MAX_HIT_POINTS;
	
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	}

	public void TakeDamage (int amount) {
		if (this.isServer) {
			this.hitPoints -= amount;
			if (this.hitPoints <= 0) {
				this.hitPoints = 0;
				Debug.Log("Dead!");

				if (this.gameObject.GetComponent<PlayerMove>() != null) {
					// Reinicia jogador. Soh os clientes executarao esse metodo
					RpcRespawn();

					this.hitPoints = MAX_HIT_POINTS;
				}
				else {
					// Nao eh jogador, destroi o objeto
					Destroy(this.gameObject);
				}
			}
		}
	}
	
	[ClientRpc]
	void RpcRespawn () {
		if (this.isLocalPlayer) {
			this.transform.position = Vector3.zero;
			this.transform.rotation = Quaternion.identity;
		}
	}
}
