﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using Bitrave.Azure;

public class AzureUILeaderboard : MonoBehaviour
{
    private AzureMobileServices azure;

    [SerializeField]
    public string AzureEndPoint = "COLOQUE AQUI O APPLICATION URI"; // Your Connection URL

    // Table items
    public List<Leaderboard> _leaderboardItems = new List<Leaderboard>();

    // Use this for initialization
    void Start()
    {
        azure = new AzureMobileServices(AzureEndPoint);
    }

    // Update is called once per frame
    void Update()
    {

    }

    // Interface
    private int width = 44;
    private int height = 44;
    private int colWidth = 200;

    // Item to insert
    private Leaderboard _leaderboard = new Leaderboard()
    {
        Score = 0,
        Username = "Anon"
    };

    // Item to update
    private Leaderboard _selectedItem = new Leaderboard()
    {
        Score = 0,
        Username = "Anon"
    };

    private Vector2 scrollPosition;

    public void OnGUI()
    {
        GUILayout.BeginVertical();
        GUILayout.BeginHorizontal();

        // Column 1
        GUILayout.BeginVertical(GUILayout.Width(colWidth));
        GUILayout.Label("Azure End Point");
        AzureEndPoint = GUILayout.TextField(AzureEndPoint, GUILayout.Width(colWidth));
        GUILayout.Label("Game");
        _leaderboard.game = GUILayout.TextField(_leaderboard.game, GUILayout.Width(colWidth));
        GUILayout.EndVertical();

        // hide rest of GUI if no connection available
        GUI.enabled = (azure != null);

        // Column 2
        GUILayout.BeginVertical(GUILayout.Width(colWidth));
        GUILayout.Label("Username");
        _leaderboard.Username = GUILayout.TextField(_leaderboard.Username);
        GUILayout.Label("Score");
        _leaderboard.Score = Convert.ToInt32(GUILayout.TextField("" + _leaderboard.Score));
        if (GUILayout.Button("Add Score", GUILayout.MinWidth(width), GUILayout.Height(height)))
        {
            // Note: You don't need to do the following, it's done in the insert method. 
            // _leaderboard.Id = null;

            if (_leaderboard.Score > 0)
            {
                // only insert score if greater than 0
                azure.Insert<Leaderboard>(_leaderboard);
            }
            else
            {
                Debug.Log("Score must be > 0 to insert");
            }
        }
        GUILayout.Label("Id: " + _leaderboard.Id); // unique item Id (returned once submitted succesfully)
        GUILayout.EndVertical();

        // Column 3
        GUILayout.BeginVertical(GUILayout.Width(colWidth));
        if (GUILayout.Button("Query User Scores", GUILayout.MinWidth(width), GUILayout.Height(height)))
        {
            _leaderboardItems.Clear();
            // get a user's scores
            azure.Where<Leaderboard>(p => p.game == _leaderboard.game && p.Username == _leaderboard.Username, ReadHandler);
        }
        if (GUILayout.Button("List All Scores", GUILayout.MinWidth(width), GUILayout.Height(height)))
        {
            GetAllItems();
        }
        if (GUILayout.Button("List Scores 500+", GUILayout.MinWidth(width), GUILayout.Height(height)))
        {
            _leaderboardItems.Clear();
            // get high scores
            azure.Where<Leaderboard>(p => p.game == _leaderboard.game && p.Score >= 500, ReadHandler);
        }
        GUILayout.Label("Item count: " + _leaderboardItems.Count);
        scrollPosition = GUILayout.BeginScrollView(scrollPosition, false, true, GUILayout.Height(300));

        // Column 4
        GUILayout.BeginVertical();
        foreach (var item in _leaderboardItems)
        {
            GUILayout.BeginHorizontal();
            if (GUILayout.Button(">", GUILayout.Width(width), GUILayout.Height(height)))
            {
                _selectedItem = item;
            }
            GUILayout.Label(item.Username);
            GUILayout.Label(Convert.ToString(item.Score));
            GUILayout.EndHorizontal();
        }
        GUILayout.EndVertical();

        GUILayout.EndScrollView();
        GUILayout.EndVertical();

        GUILayout.BeginVertical(GUILayout.Width(colWidth));

        var was = GUI.enabled;

        GUI.enabled = _selectedItem.Id != null;

        GUILayout.Label("Id: " + _selectedItem.Id);
        if (_selectedItem.Score > 0)
        {
            _selectedItem.Score = Convert.ToInt32(GUILayout.TextField("" + _selectedItem.Score));
        }
        _selectedItem.Username = GUILayout.TextField(_selectedItem.Username);

        if (GUILayout.Button("Update", GUILayout.MinWidth(width), GUILayout.Height(height)))
        {
            azure.Update<Leaderboard>(_selectedItem);
        }
        if (GUILayout.Button("Delete", GUILayout.MinWidth(width), GUILayout.Height(height)))
        {
            azure.Delete<Leaderboard>(_selectedItem);
        }

        GUI.enabled = was;

        GUILayout.EndVertical();
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        GUILayout.EndHorizontal();

        GUILayout.EndVertical();

        GUI.enabled = true;
    }

    public void GetAllItems()
    {
        _leaderboardItems.Clear();
        azure.Where<Leaderboard>(p => p.game == _leaderboard.game && p.Username != null, ReadHandler);
    }

    public void ReadHandler(AzureResponse<List<Leaderboard>> response)
    {

        var list = response.ResponseData;

        Debug.Log("Items ==================");
        foreach (var item in list)
        {
            Debug.Log(Convert.ToString(item.Score) + "," + item.Username + "," + item.Id);
            _leaderboardItems.Add(item);
        }
        Debug.Log("==================");
    }

}

